// Name: 

#include "HashMap.hpp"
#include "HashNode.hpp"
#include <iostream>
#include <cmath>
using namespace std;

hashMap::hashMap(bool hash1, bool coll1) {
	
}

hashMap::~hashMap() {
	for(int i=0; i<mapSize; i++) {
		if(map[i] != NULL) {
			delete map[i];
			map[i] = NULL;
		}
	}
	delete [] map;
}

void hashMap::addKeyValue(string k, string v) {
	
}

int hashMap::getIndex(string k) {
	return 0;
}

int hashMap::calcHash2(string k){
	return 0;	
}

int hashMap::calcHash1(string k){
	return 0;
}

void hashMap::getClosestPrime() {
	
}

void hashMap::reHash() {
	
}

int hashMap::coll1(int h, int i, string k) {
	return 0;
}

int hashMap::coll2(int h, int i, string k) {
	return 0;
}

void hashMap::printMap() {
	cout << "Hash Map:" << endl;
	for (int i = 0; i < mapSize; i++) {
		// print valid values
		if (map[i] != NULL) {
			printf("[%6d] ", i);
			cout << map[i]->keyword << ": ";
			for (int j = 0; j < map[i]->currSize;j++) {
				cout << map[i]->values[j] << ", ";
			}
			cout << endl;
		}
	}
	cout << "Total Keys: " << numKeys << endl;
	cout << "Hash Map Array Size: " << mapSize << endl;
}


